//
//  MovieDetails.swift
//  hi
//
//  Created by McCormack on 10/21/17.
//  Copyright © 2017 labuser. All rights reserved.
//

import Foundation
