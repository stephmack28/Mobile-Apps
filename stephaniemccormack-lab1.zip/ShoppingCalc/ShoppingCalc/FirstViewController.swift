//
//  FirstViewController.swift
//  ShoppingCalc
//
//  Created by olin on 9/12/17.
//  Copyright © 2017 Stephanie McCormack. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    
    @IBOutlet weak var OrigPrice: UITextField! 
    @IBOutlet weak var discPerc: UITextField!
    @IBOutlet weak var taxPerc: UITextField!
    @IBOutlet weak var finalPriceLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateFinalPrice(){
        if let valP = Double(OrigPrice.text!){
            if let valD = Double(discPerc.text!){
                if let valT = Double(taxPerc.text!){
                    let valFin = valP + valP*(valT/100.0) - valP*(valD/100.0)
                    //get error on above line upon inserting data into text box
                    //finalPriceLabel.text = "\(valFin)"

                    finalPriceLabel.text = "$\(String(format: "%.2f", valFin))"
                }
            }
        }
        
        
        
        
        
        
    }
    
    @IBAction func priceUpdate(_ sender: UITextField) {
        updateFinalPrice()
    }
    @IBAction func discUpdate(_ sender: UITextField) {
        updateFinalPrice()
    }
    @IBAction func salesUpdate(_ sender: UITextField) {
        updateFinalPrice()
    }
    


}

