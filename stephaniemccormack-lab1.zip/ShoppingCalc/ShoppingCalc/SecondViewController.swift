//
//  SecondViewController.swift
//  ShoppingCalc
//
//  Created by olin on 9/12/17.
//  Copyright © 2017 Stephanie McCormack. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var checkPrice: UITextField!
    @IBOutlet weak var tipAmt: UISlider!
    @IBOutlet weak var tipPerc: UILabel!
    @IBOutlet weak var checkAmt: UILabel!
    @IBOutlet weak var sliderValue: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func updateValues() {
        let num = Int(tipAmt.value)
        if let checkVal = Double(checkPrice.text!){
            let tLabelValue = checkVal*(Double(num)/100.0)
            tipPerc.text = "Tip Amount: $\(String(format:"%.2f",tLabelValue))"
            
            let cLabelValue = checkVal + tLabelValue
            
            checkAmt.text = "Total Check Amount: $\(String(format:"%.2f",cLabelValue))"
            
            
        }
    }
    
    @IBAction func priceUpdated(_ sender: UITextField) {
        updateValues()
    }
    //Source: https://stackoverflow.com/questions/34460823/round-double-to-0-5
    
    @IBAction func tipUpdated(_ sender: UISlider) {
        let num = Int(tipAmt.value)
        sliderValue.text = "\(num)"
        updateValues()
    }

}

