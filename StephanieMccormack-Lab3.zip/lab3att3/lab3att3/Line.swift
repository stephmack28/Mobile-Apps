//
//  Line.swift
//  lab3att3
//
//  Created by McCormack on 10/2/17.
//  Copyright © 2017 McCormack. All rights reserved.
//

import UIKit

struct Line{
    var points = [CGPoint]()
    //var endPoint: CGPoint
    var lineColor: UIColor
    var lineThickness: CGFloat
}
